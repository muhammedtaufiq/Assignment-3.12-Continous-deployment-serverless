# Assignment-3.12-Continous-deployment-serverless

**OBJECTIVE**
The objective of this assignment is to set up a continuous integration and continuous deployment (CI/CD) pipeline for a Node.js application that is deployed on a serverless platform.


